#!/usr/bin/python3
# ==================================================================
# tbping v1.1
# Copyright (c) 2020 Joel Caturia <jcaturia@katratech.com>
# ==================================================================
#
# This program is free software: you can redistribute it and/or modify  
# it under the terms of the GNU General Public License as published by  
# the Free Software Foundation, version 3.
#
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License 
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#
# REVISION HISTORY:
# - v1.1 - December 11, 2020 - Resolved an issue with the listener thread crashing when running on Windows.
#                              Thanks to Stephen P. for reporting this. - Joel Caturia 
# - v1.0 - December 7, 2020  - Added UDP listener, fields and delimiter options - Joel Caturia
# - v0.9 - December 4, 2020  - Initial Release - Joel Caturia
#
# TODO/ROADMAP:
# - Add a completion message showing number of IPs probed, and [if listening]
#   the number of IPs that responded with data.
#
# KNOWN ISSUES:
# - We do not currently support DNS hostnames. Is this really that important to anyone?
# - If you have a filename in your current directory that happens to be a properly
#   formatted IP address, we will try and open that file and read data out of it.
#
#
# ==================================================================
# tbping - Joel Caturia <jcaturia@katratech.com> - A tool for poking Extron
# devices that are Toolbelt enabled. It encourages them to push their
# information to your running Toolbelt application (on the same computer). This
# is very useful when you have equipment that crosses Layer3/router boundaries
# (which block broadcasts from Toolbelt).
#
# When used independent of Toolbelt,
# tbping can also be used in a "listener" mode where the responses from the
# various devices can be printed to STDOUT for inventory and system
# administration tasks. The exact fields and field delimiter can be adjusted to
# accomplish a variety of use cases.#
# positional arguments:
#   <HOST/SUBNET/FILE>    Either: 1) Single IP of a Toolbelt-enabled device, 2)
#                         An entire subnet range to poke using CIDR notation, or
#                         3) A filename to a file that contains a list of IP
#                         addresses and subnets to read in and operate on.
#
# optional arguments:
#   -h, --help            show this help message and exit
#   --quiet, -q           Run quietly. Does not output status information as the
#                         program runs. This does _not_ prevent the responses
#                         from the listener from being displayed.
#   --delay DELAY, -d DELAY
#                         Sets the delay between probe packets. Defaults to
#                         .25s.
#   --port PORT, -p PORT  Port to send the probe to. Defaults to 4502. (It is
#                         unlikely you would ever need to change this.)
#   --listen, -l          Listen for responses from Toolbelt-enabled devices
#                         (does not work when the Toolbelt application is
#                         running!)
#   --wait, -w            When listening, causes tbping to enter an endless
#                         loop, so it will continue listening until you press
#                         CTRL+C to terminate the program.
#   --raw, -r             Show the raw data received from the device, without
#                         any parsing.
#   --fields FIELDS       When listening, changes the various fields used to
#                         generate the program output. Separate field names by a
#                         comma. Use the --raw function to find out what sort of
#                         fields your device is returning. Defaults to: "model,
#                         partnum, snum, mac_address, ip_address, systemid"
#   --delimiter DELIMITER
#                         When listening, changes the delimiter used between
#                         fields when generating program output. Defaults to a
#                         comma and a space. Can be multiple characters.
#
# --- WARNING --- Be careful when using this tool to probe entire subnets. This
# type of network traffic could easily be mis-interpreted as malicious network
# traffic by a network security device. How that is detected, and whether your
# network traffic is blocked, ignored, or otherwise adjusted is left up to the
# people who manage the security devices.
# ==================================================================


import argparse
import ipaddress # requires Python 3.3+
import socket
import sys
import time

# Used for "listen" feature
import json
import re
from threading import Thread


def process_commandline_args():
    """
    Uses the argparse library to parse our command-line parameters to control program execution.

    Parameters
    ----------
    None

    Returns
    -------
    object/Namespace
        Argparse options
    """

    args = argparse.ArgumentParser(
        description='tbping - Joel Caturia <jcaturia@katratech.com> - A tool for poking Extron devices\
        that are Toolbelt enabled. It encourages them to push their information to your running Toolbelt\
        application (on the same computer). This is very useful when you have equipment that crosses\
        Layer3/router boundaries (which block broadcasts from Toolbelt).\
        When used independent of Toolbelt, tbping can also be used in a "listener" mode where the responses\
        from the various devices can be printed to STDOUT for inventory and system administration tasks.\
        The exact fields and field delimiter can be adjusted to accomplish a variety of use cases.',

        epilog='--- WARNING --- Be careful when using this tool to probe entire subnets. This type of network\
        traffic could easily be mis-interpreted as malicious network traffic by a network security device.\
        How that is detected, and whether your network traffic is blocked, ignored, or otherwise adjusted\
        is left up to the people who manage the security devices.'
        )

    args.add_argument(metavar='<HOST/SUBNET/FILE>', dest='target', help='\
        Either: 1) Single IP of a Toolbelt-enabled device, 2) An entire subnet range to poke using\
        CIDR notation, or 3) A filename to a file that contains a list of IP addresses and subnets to\
        read in and operate on.')

    args.add_argument('--quiet', '-q', help='Run quietly. Does not output status information as the program runs.\
        This does _not_ prevent the responses from the listener from being displayed.', action='store_true')

    args.add_argument('--delay', '-d', help='Sets the delay between probe packets. Defaults to .25s.',
           action='store', type=float, default=.25)

    args.add_argument('--port', '-p', help='Port to send the probe to. Defaults to 4502. (It is unlikely you\
        would ever need to change this.)', action='store', type=int, default=4502)

    args.add_argument('--listen', '-l', help='Listen for responses from Toolbelt-enabled devices (does not work\
        when the Toolbelt application is running!)', action='store_true')

    args.add_argument('--wait', '-w', help='When listening, causes tbping to enter an endless loop,\
        so it will continue listening until you press CTRL+C to terminate the program.', action='store_true')

    args.add_argument('--raw', '-r', help='Show the raw data received from the device, without any parsing.'\
        , action='store_true')

    args.add_argument('--fields', help='When listening, changes the various fields used to generate the\
        program output. Separate field names by a comma. Use the --raw function to find out what sort of\
        fields your device is returning. Defaults to: \"model, partnum, snum, mac_address, ip_address, systemid\"',
        action='store', type=str, default='model,  partnum,snum,version,    mac_address,ip_address,systemid')

    args.add_argument('--delimiter', help='When listening, changes the delimiter used between fields when\
        generating program output. Defaults to a comma and a space. Can be multiple characters.',
        action='store', type=str, default=', ')

    options = args.parse_args()

    # TODO - Can this be a custom argparse handler function? Perhaps that would be more Pythonic?
    # These two lines parse our --fields parameter into a list, then store that in the argparse object
    # that we are going to pass around the entire program. This is an example of list comprehension in Python,
    # which lets us to a "split" then a "strip" in a single line.
    fields = [x.strip() for x in options.fields.split(',')]
    setattr(options, 'field_names', fields)

    return options


def test_valid_ip_address(ip_to_test):
    """
    Uses the ipaddress module to test if a passed in IP address is a valid host
    or subnet IP (with CIDR notation). It will return False if something is wrong,
    and it will return an object of type IPv4Network if it is valid. 

    Parameters
    ----------
    ip_to_test : str
        The IP address to test.

    Returns
    -------
    object/IPv4Network _OR_ boolean/False
        Will return False if parameter is not a valid IP address, otherwise will
        return an object of type IPv4Network.
    """

    try:
        network = ipaddress.IPv4Network(ip_to_test)
        return network
        
    except ValueError:
        return False


def process_line(line_from_file):
    """
    Processes a line read from a data file (or as a command-line parameter)
    If the data yields a valid host/subnet IP address, this function returns a
    list of one or more host IP addresses (it also breaks down a subnet into individual
    host IP addresses.) 

    Parameters
    ----------
    line_from_file : str
        Description of arg1

    Returns
    -------
    list _OR_ boolean/False
        Returns a list of one or more host IP addresses _OR_ False if the passed in parameter
        did not validate as an IP address.
    """
    
    network = test_valid_ip_address(line_from_file)

    if network is not False:
        if network.prefixlen == 32: # We know this is the IP of a hostname, since our netmask is 32
            return [str(network.network_address)]

        else: # Return a list of all IPs in this subnet using the generator provided by the ipaddress module
            return list(network.hosts())
    
    else:
        return False


def send_udp_packet(socket_object, ip_address, udp_port):
    """
    Send UDP probe packet to a specific IP address, on a specified UDP port

    Parameters
    ----------
    socket_object : object/socket
        Python socket object to use for sending UDP packets
    ip_address : str
        IP Address to send the UDP probe packet to
    udp_port : int
        UDP port to use (should be 4502 under normal circumstances)

    Returns
    -------
    boolean
        True if we believe it succeeded, False if we encountered an error sending the packet
    """
    
    send_data = b'fD2200007FFFFFFF0000FFF0FFFFFFF00000004E[{"method":"get","uri":"/scm/devices/self","replyto":"/scm/devices/self"}]fE'
    
    try:
        socket_object.sendto(send_data, (ip_address, udp_port))
        return True

    except OSError as e:
        print('ERROR: Encountered an error while sending probe: [{}]'.format(e))
        return False


def send_probe_to_targets(network_socket, target_list, options):
    """
    Loops through a provided list of target IP addresses, and sends UDP probes to
    each of them. Also supports making sure there is (a configurable) a delay between them.

    Parameters
    ----------
    network_socket : object/socket
        Python socket object to use for sending UDP packets
    target_list : list
        A list containing target IP addresses
    options : object/argparse
        The argparse object containing all of our command-line parameters

    Returns
    -------
    None
    """

    # Iterate through our "target_list" list and send the probe packet
    for single_ip in target_list:
        if options.quiet is False:
            print('Sending tbping to {}, with a delay of {}s between packets'.format(single_ip, options.delay))

        send_udp_packet(network_socket, str(single_ip), options.port)
        time.sleep(options.delay)


def thread_worker_incoming_udp(socket_object, options):
    """
    This function is intended to be run as an independent thread. It will use basic blocking
    UDP socket functionality to process incoming data on a specific port. The incoming data
    will be parsed at a naive level with a regex, and then hopefully what is left will successfully
    parse into a Python dictionary with the json.loads function.

    Parameters
    ----------
    socket_object : object/socket
        Python socket object to use for receiving/sending UDP packets
    options : object/argparse
        The argparse object containing all of our command-line parameters

    Returns
    -------
    None
    """

    compiled_regex = re.compile(r'fD[0-9A-F]+\[(.+)\]fE')

    # Endless loop! Keep running until we get terminated by our parent process
    while True:
        try:
            data, address = socket_object.recvfrom(4096)  # This will block here until data arrives

            if data:
                if options.raw is True:
                    print ('\nRAW: Received data from {}\n{}\n'.format(address[0], data))

                else:
                    try:
                        regex_match = compiled_regex.match(data.decode())

                        if regex_match:
                            device_data = json.loads(regex_match.group(1))

                            # Iterate through our requested field names and see if we have anything by that name
                            # in our JSON payload. If we do we'll use it, if not we just print a blank field
                            # and keeping moving.
                            field_data = []
                            for single_field in options.field_names:
                                #print('FIELD ->', single_field)
                                if single_field in device_data['value']:
                                    field_data.append(str(device_data['value'][single_field]))
                                
                                else:
                                    field_data.append('')

                            print(options.delimiter.join(field_data))
                            
                        else:
                            print('WARNING: Data arrived but it did not match what we expected. You could try the\
                             --raw parameter to see if our internal regex needs some adjustment.')

                    except:
                        print('ERROR: An error occured while parsing data from {}. Attempting to continue..'.format(
                            address[0]))
        
        except:
            pass


def main():
    """
    Main function: Opens the necessary network sockets, parses commandline arguments,
    and passes control to various functions that perform a specific task and return
    data back to further use.

    Parameters
    ----------
    None

    Returns
    -------
    None
    """

    # Parse our arguments to figure out how we will try to operate
    options = process_commandline_args()

    # Create socket object to use for UDP network traffic
    network_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, 0)
    #network_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)


    # If we specified the "listen" command-line parameter, this section binds our UDP socket to a port
    # (starts listening), and intantiates the listener thread to handle the incoming data.
    if options.listen is True:
        try:
            network_socket.bind( ('', options.port) )

            t = Thread(target=thread_worker_incoming_udp, args=(network_socket, options), daemon=True)
            t.start()

        except:
            print('ERROR: Unable to bind to port [{}]. Continuing to run, but you will not see returned data.\
                \nDo you already have Toolbelt running in Discovery mode perhaps?\n'.format(options.port))


    # This list will hold all of our intended network targets
    target_ips = []

    # The first thing we do is try to see if our target parameter is a filename to a data file we can process
    # We catch the "FileNotFoundError" exception in order to determine that the thing provided on the
    # commandline was not a valid filename.
    try:
        with open(options.target) as fp:
            for single_line in fp:
                single_line = single_line.strip()

                # We ignore comments, and blank lines in our files
                if single_line.startswith('#') or len(single_line) < 1:
                    continue

                # returned_targets will be a list of one or more IP address, or False if it was an invalid line
                returned_targets = process_line(single_line)
                
                if returned_targets is not False:
                    target_ips.extend(returned_targets)

                else:
                    print('WARNING: Ignoring malformed data (or invalid IP addresses) in file -> {}'.
                        format(single_line))


        if len(target_ips) < 1:
            print('ERROR: No valid IP addresses present in the specified file [{}]. Exiting..'.format(options.target))
            sys.exit(2)

    except FileNotFoundError:
        returned_targets = process_line(options.target)
        
        # returned_targets will be a list of one or more IP address, or False if it was an invalid line
        if returned_targets is not False:
            target_ips.extend(returned_targets)

        else:
            print('ERROR: File specified [{}] does not exist. Exiting..'.format(options.target))
            sys.exit(1)

    
    # This function is where all of the network traffic is generated
    send_probe_to_targets(network_socket, target_ips, options)


    # This will ensure there is time for a response to come in from devices before we close down our UDP port.
    if options.listen is True:
        
        # This parameter will enter an endless loop, so we can continue to receive data from devices
        if options.wait is True:
            try:
                print('Wait mode active. Continuing to listen to UDP port. Press CTRL+C to exit program.\n')
                
                while True:
                    time.sleep(10)
            
            except KeyboardInterrupt:
                print('\nCTRL+C Detected! Exiting..\n')

        else:
            if options.quiet is False:
                print('Finishing up..')
        
            time.sleep(1)


    # Close the socket
    network_socket.close()

###############################################################################


if __name__ == "__main__":
    try:
        main()

    except SystemExit:
        pass

    except KeyboardInterrupt:
        print('\nCTRL+C Detected! Exiting..\n')

    except:
        print('The program encountered an exception and we did not handle it well. Exiting with stack trace..')
        raise
